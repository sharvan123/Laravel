<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class HomeController extends Controller
{
    public function index()
    {
    	$banner = DB::table('banners')->get();
    	return view('index',['banner'=>$banner]);
    }
}
