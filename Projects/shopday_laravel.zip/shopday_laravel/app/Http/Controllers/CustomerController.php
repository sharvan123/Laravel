<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Customer;
use Hash;
use Laravel\Socialite\Facades\Socialite;
use Auth;

class CustomerController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = '/my-account';

    public function login()
    {
        if(Auth::check())
        {
            return view('my_account');
        }
    	return view('login');
    }

    public function register()
    {
    	return view('register');
    }

    public function customer_register(Request $request)
    {
    	$request->validate([

    		'name'=>'required',
    		'email'=>'required',
    		'password'=>'required',
    		'confirm_password'=>'required|same:password'
    	]);

    	$data = [
    		'name'=>$request->name,
    		'email'=>$request->email,
    		'password'=>Hash::make($request->password),
    		'remember_token'=>$request->_token,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
    	];

    	Customer::insert($data);

    	return redirect('login');
    }

    public function login_check(Request $request)
    {
    	$request->validate([

    		'email'=>'required',
    		'password'=>'required',
    	]);

    	$data = [
    		'email'=>$request->email,
    		'password'=>$request->password,
    	];

    	//var_dump($data);
    	if(Auth::attempt($data))
    	{
    		return redirect('my-account');
    	}
    	else
    	{
    		return redirect('login')->with('error','These credentials do not match our records.');
    	}
    }

    public function redirectToProvider()
    {
        return Socialite::driver('google')->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
    public function handleProviderCallback()
    {
        $user = Socialite::driver('google')->stateless()->user();

        $data = [
            'name'=>$user->name,
            'email'=>$user->email,
            'password'=>Hash::make('123456789'),
            'remember_token'=>$user->token,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
        ];

        Customer::insert($data);

        $user_data = [
            'email'=>$user->email,
            'password'=>'123456789',
        ];
        if(Auth::attempt($user_data))
        {
            return redirect('my-account')->with('password','please change your password. Your default Password is 123456789');
        }
        //return $user->email;
        else
        {
            return redirect('login')->with('error','These credentials do not match our records.');
        }
    }
}
