<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Product;
use DB;
class ProductController extends Controller
{
    public function index()
    {
    	$category = DB::table('categories')->pluck('category_name','id');
    	$sub_category = DB::table('sub_categories')->get();
    	$product = Product::paginate(12);
    	return view('products',['product'=>$product , 'category'=>$category , 'sub_category'=>$sub_category]);
    
    }

    public function product_getail($id)
    {
    	$product_detail = Product::where('id',$id)->first();
    	return view('product_detail',['product_detail'=>$product_detail]);
    }

    public function sub_category_ajax_product($id)
    {
        //Product::where('id',$id)->delete();
        $product = DB::table('products')->where('sub_category_id',$id)->get();
    	return view('product_ajax',['product'=>$product]);
    }

    public function category_ajax_product($id)
    {
    	$product = DB::table('products')->where('category_id',$id)->paginate(12);
    	return view('product_ajax',['product'=>$product]);
    }
}


