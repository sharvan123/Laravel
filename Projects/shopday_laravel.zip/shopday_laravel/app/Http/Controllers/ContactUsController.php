<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Mail;

class ContactUsController extends Controller
{
    public function index()
    {
    	//$banner = DB::table('banners')->get();
    	return view('contact_us');
    }

    public function send_mail(Request $request)
    {
    	$request->validate([

    		'name'=>'required',
    		'email'=>'required|email',
    		'comment'=>'required'
    	]);

    	$data = [

    		'name'=>$request->name,
    		'email'=>$request->email,
    		'comment'=>$request->comment,
    		'ip'=> $_SERVER['REMOTE_ADDR'],
    		'created_at' => date('Y/m/d H:i:s'),
    		'updated_at' => date('Y/m/d H:i:s'),
    	];

    	DB::table('enquiries')->insert($data);

    	Mail::send('email.contact_us_email', $data, function($message) use ($data){
    		
	    	//$message->to($data['email']);
            $message->to('laravel2017@gmail.com');
            $message->subject('Shop Day Enquiry');
    		//$message->from('laravel2017@gmail.com','Shop Day');
            $message->from($data['email']);
    	});

    	return back()->with('message','Your Enquiry Send Successfully..');
    }
}
