<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Customer;
class CustomerController extends Controller
{
    public function index()
    {
        $customer = Customer::paginate(10);
        return view('admin.manage_customer',['customer'=>$customer]);
    }

    public function show($id)
    {
        $customer = Customer::find($id);
        return view('admin.show_customer',['customer'=>$customer]);
    }

    public function delete($id)
    {
        Customer::where('id',$id)->delete();

        return back()->with('success','Customer delete successfully');
    }
}
