<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Category;
class CategoryController extends Controller
{
    public function index()
    {
        $category = Category::get();
        return view('admin.manage_category',['category' => $category]);
    }

    public function create()
    {
        return view('admin.add_category');
    }

    public function store(Request $request)
    {
       //dump($request->all());

       $request->validate([

        'category_name'=>'required',
      
       ]);

      //echo $banner; exit;
       $data = [
            'category_name'=>$request->category_name,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Category::insert($data);

       return redirect('admin/category')->with('success','Category insert successfully');
    }

    public function edit($id)
    {
        $category = Category::where('id',$id)->first();
        return view('admin.edit_category',['category' => $category]);
    }

    public function update(Request $request, $id)
    {
        $category = Category::where('id',$id)->first();
        $request->validate([

        'category_name'=>'required',

       ]);
       
       $data = [
            'category_name'=>$request->category_name,
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Category::where('id',$id)->update($data);

       return redirect('admin/category')->with('success','Category update successfully');
    }

    public function delete($id)
    {
        Category::where('id',$id)->delete();

        return back()->with('success','Category delete successfully');
    }
}
