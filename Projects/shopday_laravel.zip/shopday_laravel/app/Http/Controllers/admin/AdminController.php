<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Admin;
use Auth;
class AdminController extends Controller
{

    public function login()
    {
        if(Auth::guard('admin')->check())
        {
            return view('admin/dashboard');
        }
        return view('admin.login');
    }

    public function login_check(Request $request)
    {
    	$request->validate([
    		'email'=>'required',
    		'password'=>'required',
    	]);

    	$data= [
    		'email' =>$request->email,
    		'password' =>$request->password
    	];
    	if(Auth::guard('admin')->attempt($data))
    	{
    		return redirect('admin/dashboard');
    	}
    	else
    	{
    		return redirect('admin/login')->with('error','These credentials do not match our records.');	
    	}
    }

    public function logout()
    {
        Auth::guard('admin')->logout();

        return redirect('admin/login');
    }
}
