<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Enquiry;
class EnquiryController extends Controller
{
    public function index()
    {
        $enquiry = Enquiry::paginate(10);
        return view('admin.manage_enquiry',['enquiry'=>$enquiry]);
    }

    public function show($id)
    {
        $enquiry = Enquiry::find($id);
        return view('admin.show_enquiry',['enquiry'=>$enquiry]);
    }

    public function delete($id)
    {
        Enquiry::where('id',$id)->delete();

        return back()->with('success','Enquiry delete successfully');
    }
}
