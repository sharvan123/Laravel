<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Banner;
class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::get();
        return view('admin.manage_banner',['banners' => $banners]);
    }

    public function create()
    {
        return view('admin.add_banner');
    }

    public function store(Request $request)
    {
       //dump($request->all());

       $request->validate([

        'caption'=>'required',
        'banner'=>'required|image'

       ]);

       $banner="";
       if($request->hasFile('banner'))
       {
         $path= 'Upload/Banner';
         $file= $request->banner;
         $ext = $file->getclientoriginalextension();
         $fileName = rand(1111,99999).".".$ext;
         $file -> move($path,$fileName);
         $banner = $path."/".$fileName;
       }
       //echo $banner; exit;
       $data = [
            'caption'=>$request->caption,
            'banner_link'=>$request->url,
            'banner'=>$banner,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Banner::insert($data);

       return redirect('admin/banner')->with('success','Banner insert successfully');
    }

    public function edit($id)
    {
        $banners = Banner::where('id',$id)->first();
        return view('admin.edit_banner',['banners' => $banners]);
    }

    public function update(Request $request, $id)
    {
        $banners = Banner::where('id',$id)->first();
        $request->validate([

        'caption'=>'required',

       ]);
       $unlink_banner = $banners->banner;
       if($request->banner)
       {
           $banner="";
           if($request->hasFile('banner'))
           {
             $path= 'Upload/Banner';
             $file= $request->banner;
             $ext = $file->getclientoriginalextension();
             $fileName = rand(1111,99999).".".$ext;
             unlink($unlink_banner);
             $file -> move($path,$fileName);
             $banner = $path."/".$fileName;
           }
        }
        else
        {
            $banner = $banners->banner;
        }
       $data = [
            'caption'=>$request->caption,
            'banner_link'=>$request->url,
            'banner'=>$banner,
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Banner::where('id',$id)->update($data);

       return redirect('admin/banner')->with('success','Banner update successfully');
    }

    public function delete($id)
    {
        Banner::where('id',$id)->delete();

        return redirect('admin/banner')->with('success','Banner delete successfully');
    }
}
