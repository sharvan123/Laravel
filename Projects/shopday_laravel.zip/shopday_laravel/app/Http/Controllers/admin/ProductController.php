<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use DB;
class ProductController extends Controller
{
    public function index()
    {
        $product = Product::join('categories','categories.id','=','products.category_id')->join('sub_categories','sub_categories.id','=','products.sub_category_id')->selectRaw('products.id, sub_category_name, category_name, product_name, product_image')->paginate(10);
        return view('admin.manage_product',['product' => $product]);
    }

    public function create()
    {
    	$category = DB::table('categories')->pluck('category_name', 'id');
    	//$sub_category = DB::table('sub_categories')->pluck('sub_category_name', 'id');
        return view('admin.add_product',['category'=>$category]);
    }

    public function store(Request $request)
    {
       //dump($request->all());

       $request->validate([

        'category_id'=>'required',
        'sub_category_id'=>'required',
        'product_name'=>'required',
        'product_image'=>'required|image',
        'description'=>'required',
        'product_code'=>'required',
        'product_price'=>'required'

       ]);

       $product_image="";
       if($request->hasFile('product_image'))
       {
         $path= 'Upload/ProductImage';
         $file= $request->product_image;
         $ext = $file->getclientoriginalextension();
         $fileName = rand(1111,99999).".".$ext;
         $file -> move($path,$fileName);
         $product_image = $path."/".$fileName;
       }
       //echo $banner; exit;
       $data = [
            'category_id'=>$request->category_id,
            'sub_category_id'=>$request->sub_category_id,
            'product_name'=>$request->product_name,
            'product_image'=>$product_image,
            'description'=>$request->description,
            'product_code'=>$request->product_code,
            'product_price'=>$request->product_price,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Product::insert($data);

       return redirect('admin/product')->with('success','Product insert successfully');
    }

    public function edit($id)
    {
    	$category = DB::table('categories')->pluck('category_name', 'id');
    	$sub_category = DB::table('sub_categories')->pluck('sub_category_name', 'id');
        $product = Product::where('id',$id)->first();
        return view('admin.edit_product',['product' => $product, 'category'=>$category, 'sub_category'=>$sub_category]);
    }

    public function update(Request $request, $id)
    {
        $image = Product::where('id',$id)->first();
        $request->validate([

        'category_id'=>'required',
        'sub_category_id'=>'required',
        'product_name'=>'required',
        'description'=>'required',
        'product_code'=>'required',
        'product_price'=>'required'

       ]);
       $unlink_product_image = $image->product_image;
       if($request->product_image)
       {
           $product_image="";
           if($request->hasFile('product_image'))
           {
             $path= 'Upload/ProductImage';
             $file= $request->product_image;
             $ext = $file->getclientoriginalextension();
             $fileName = rand(1111,99999).".".$ext;
             unlink($unlink_product_image);
             $file -> move($path,$fileName);
             $product_image = $path."/".$fileName;
           }
        }
        else
        {
            $product_image = $image->product_image;
        }
       $data = [
            'category_id'=>$request->category_id,
            'sub_category_id'=>$request->sub_category_id,
            'product_name'=>$request->product_name,
            'product_image'=>$product_image,
            'description'=>$request->description,
            'product_code'=>$request->product_code,
            'product_price'=>$request->product_price,
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       Product::where('id',$id)->update($data);

       return redirect('admin/product')->with('success','Product update successfully');
    }

    public function delete($id)
    {
        Product::where('id',$id)->delete();

        return back()->with('success','Product delete successfully');
    }

    public function sub_category($id)
    {
        //Product::where('id',$id)->delete();
        $sub_category = DB::table('sub_categories')->where('category_id', $id)->pluck('sub_category_name', 'id');
    	//return $id;
        return view('admin.sub_category_ajax',['sub_category'=>$sub_category]);
    }
}
