<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\SubCategory;
use DB;
class SubCategoryController extends Controller
{
    public function index()
    {
        $sub_category = SubCategory::join('categories','categories.id','=','sub_categories.category_id')->selectRaw('sub_categories.id, sub_category_name, category_name')->paginate(10);
        return view('admin.manage_sub_category',['sub_category' => $sub_category]);
    }

    public function create()
    {
    	$category = DB::table('categories')->pluck('category_name', 'id');
        return view('admin.add_sub_category',['category' => $category]);
    }

    public function store(Request $request)
    {
       //dump($request->all());

       $request->validate([

        'category_id'=>'required',
        'sub_category_name'=>'required'
      
       ]);

      //echo $banner; exit;
       $data = [
            'category_id'=>$request->category_id,
            'sub_category_name'=>$request->sub_category_name,
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       SubCategory::insert($data);

       return redirect('admin/sub-category')->with('success','Sub Category insert successfully');
    }

    public function edit($id)
    {
    	$category = DB::table('categories')->pluck('category_name', 'id');
        $sub_category = SubCategory::where('id',$id)->first();
        return view('admin.edit_sub_category',['sub_category' => $sub_category , 'category' => $category]);
    }

    public function update(Request $request, $id)
    {
        $sub_category = SubCategory::where('id',$id)->first();
        $request->validate([

        'category_id'=>'required',
        'sub_category_name'=>'required'

       ]);
       
       $data = [
            'category_id'=>$request->category_id,
            'sub_category_name'=>$request->sub_category_name,
            'updated_at'=>date('Y-m-d H:i:s')
       ];

       SubCategory::where('id',$id)->update($data);

       return redirect('admin/sub-category')->with('success','Sub Category update successfully');
    }

    public function delete($id)
    {
        SubCategory::where('id',$id)->delete();

        return back()->with('success','Sub Category delete successfully');
    }
}
