<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
class DashboardController extends Controller
{
	public function __construct()
    {
        $this->middleware('admin');

        //$this->middleware('log', ['only' => ['fooAction', 'barAction']]);

        //$this->middleware('subscribed', ['except' => ['fooAction', 'barAction']]);
    }

    public function index()
    {
        if(Auth::guard('admin')->check())
        {
    	   return view('admin.dashboard');
        }
        return view('admin.login');
    }
}
