<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['category_id','sub_category_id','product_name','product_image','description','product_code','product_price','is_offer','product_special_price'];

}
