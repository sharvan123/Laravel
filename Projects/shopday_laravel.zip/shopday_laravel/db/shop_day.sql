-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2020 at 11:40 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop_day`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `remember_token`) VALUES
(1, 'Master Admin', 'brijesh@gmail.com', '$2y$10$dQ.nFN7UBnauWsJ5oFErXeNr1KC.7TpO5shDQUZqUnDaiuOtBpzsu', 'wVlv0Vj9EjhjqjxFNU0A7RgMmR23h7GgItFiGvL1i5HDKUht3iky6tooIxIR');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(10) UNSIGNED NOT NULL,
  `caption` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banner_link` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `caption`, `banner_link`, `banner`, `created_at`, `updated_at`) VALUES
(2, 'Internet Marketing', 'http://google.com', 'Upload/Banner/1785.jpg', '2017-11-15 00:20:14', '2019-12-25 13:46:49'),
(3, 'wa280 banner', '', 'Upload/Banner/80130.jpg', '2017-11-14 23:50:46', '2017-11-14 23:50:46');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'Electronics', '2017-11-15 12:26:54', '2017-11-15 12:26:54'),
(2, 'Man', '2017-11-15 12:27:10', '2017-11-15 12:27:10'),
(3, 'Women', '2017-11-15 12:27:25', '2017-11-15 12:27:25'),
(4, 'Baby & Kids', '2017-11-15 12:27:57', '2017-11-15 12:27:57'),
(5, 'Home & Furniture', '2017-11-15 12:28:13', '2017-11-15 12:28:13'),
(6, 'Book & More', '2017-11-15 12:28:29', '2017-11-15 12:28:29');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `password`, `remember_token`, `mobile`, `address`, `city`, `state`, `country`, `created_at`, `updated_at`) VALUES
(1, 'laravel laravel', 'laravel2017@gmail.com', '$2y$10$26TpyJK8DcuooGalM8ZDbeYyICn3URX3hNWXRjv6Hy.Vbev6Z/07O', 'ya29.GlsJBf86esnG7zdeqvCofthmDCSER9UhW3oEAV5j_igaJ6WeQAzavSmRfAACjE0tQIzk2ImwrGdcm6hNkEB3CuBH-bRmS2P7k-d0drS5ZUc3b6xuUV9zQH-tH_aX', NULL, NULL, NULL, NULL, NULL, '2019-11-19 12:31:13', '2019-11-19 12:31:13'),
(2, 'brijesh', 'b@gmail.com', '$2y$10$bf9w25A8zvLNSXOMqsHzsudt8CPccsg6iHgq9PmGO067F8qdX7w6G', '6UGzI0I1FhDPJ6Jm8Ny04gVIVou5TmD5xtPgRqAailjbtRyZvHaEKw1GXPyY', NULL, NULL, NULL, NULL, NULL, '2019-12-25 13:19:44', '2019-12-25 13:19:44');

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `name`, `email`, `comment`, `ip`, `created_at`, `updated_at`) VALUES
(1, 'shani', 'bhalani.shani@gmail.com', 'hello.....', '::1', '2017-11-19 01:02:58', '2017-11-19 01:02:58'),
(5, 'shani', 'bhalani.shans@gmail.com', 'hello... Shani......!', '::1', '2019-11-23 01:50:07', '2019-11-17 01:50:07'),
(6, 'Bhalani Bhavin', 'bhalani.bhavin.s@gmail.com', 'Hello This is a test enquiry.....', '::1', '2017-11-17 01:54:56', '2017-11-17 01:54:56');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2017_11_14_122309_create_banners_table', 1),
(3, '2017_11_15_024559_create_categorys_table', 2),
(4, '2017_11_15_035613_create_sub_categories_table', 2),
(5, '2017_11_15_053801_create_products_table', 3),
(6, '2017_11_15_155943_create_enquiries_table', 4),
(7, '2017_11_17_230822_create_customers_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `product_name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` decimal(18,2) NOT NULL,
  `is_offer` int(11) NOT NULL DEFAULT '0',
  `product_special_price` decimal(18,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `sub_category_id`, `product_name`, `product_image`, `description`, `product_code`, `product_price`, `is_offer`, `product_special_price`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Samsung Galaxy J7 Pro (Black, 64 GB)  (3 GB RAM)', 'Upload/ProductImage/30475.png', '3 GB RAM | 64 GB ROM | Expandable Upto 128 GB\r\n5.5 inch Full HD Display\r\n13MP Rear Camera | 13MP Front Camera\r\n3600 mAh Battery\r\nExynos Octa-Core 1.6GHz Processor', 'B64G3GR', '19595.00', 0, NULL, '2017-11-15 18:08:43', '2017-11-17 02:16:21'),
(2, 1, 1, 'Lenovo Phab 2 (Champagne Gold, 32 GB)  (3 GB RAM)', 'Upload/ProductImage/3100.jpg', '3 GB RAM | 32 GB ROM | Expandable Upto 128 GB\r\n6.4 inch HD Display\r\n13MP Rear Camera | 5MP Front Camera\r\n4050 mAh Li-Polymer Battery\r\nMTK8735 Processor', 'LP232G3GR', '9999.00', 0, NULL, '2017-11-17 02:19:07', '2017-11-17 02:19:07'),
(3, 1, 1, 'Redmi Note 4 (Black, 64 GB)  (4 GB RAM)', 'Upload/ProductImage/77842.jpg', '4 GB RAM | 64 GB ROM | Expandable Upto 128 GB\r\n5.5 inch Full HD Display\r\n13MP Rear Camera | 5MP Front Camera\r\n4100 mAh Li-Polymer Battery\r\nQualcomm Snapdragon 625 64-bit Octa Core 2GHz Processor', 'RN464G4GR', '11999.00', 0, NULL, '2017-11-17 02:20:54', '2017-11-17 02:20:54'),
(4, 1, 1, 'Moto Z Play with Style Mod (Black, 32 GB)  (3 GB RAM)', 'Upload/ProductImage/98787.jpg', '3 GB RAM | 32 GB ROM | Expandable Upto 2 TB\r\n5.5 inch Full HD Display\r\n16MP Rear Camera | 5MP Front Camera\r\n3510 mAh Battery\r\nQualcomm Snapdragon 625 Octa Core 2GHz Processor', 'MZPwSM32G3GR', '24999.00', 0, NULL, '2017-11-17 02:23:26', '2017-11-17 02:23:26'),
(5, 1, 1, 'OPPO F1s (Grey, 64 GB)  (4 GB RAM)', 'Upload/ProductImage/47192.jpg', '4 GB RAM | 64 GB ROM | Expandable Upto 128 GB\r\n5.5 inch HD Display\r\n13MP Rear Camera | 16MP Front Camera\r\n3075 mAh Battery\r\nMediatek MT6750 64-bit Octa Core 1.4GHz Processor', 'OF1sG64G4GR', '17949.00', 0, NULL, '2017-11-17 02:25:36', '2017-11-17 02:25:36'),
(6, 1, 1, 'Apple iPhone 6s (Space Grey, 32 GB)', 'Upload/ProductImage/51119.jpg', '32 GB ROM |\r\n4.7 inch Retina HD Display\r\n12MP Rear Camera | 5MP Front Camera\r\n1715 mAh Li-Ion Battery\r\nApple A9 64-bit processor and Embedded M9 Motion Co-processor', 'Ai6sSG32G', '37000.00', 0, NULL, '2017-11-17 02:28:47', '2017-11-17 02:28:47'),
(7, 1, 1, 'VIVO V5s Perfect Selfie (Matte Black, 64 GB)  (4 GB RAM)', 'Upload/ProductImage/48246.jpeg', '4 GB RAM | 64 GB ROM | Expandable Upto 256 GB\r\n5.5 inch HD Display\r\n13MP Rear Camera | 20MP Front Camera\r\n3000 mAh Li-Ion Battery\r\nMediaTek MT6750 64-bit Octa Core 1.5GHz Processor', 'VV5sPSMB64g4GR', '17990.00', 0, NULL, '2017-11-17 02:32:08', '2017-11-17 02:32:08'),
(8, 1, 2, 'Samsung EVO Plus 32 GB MicroSDHC Class 10 95 MB/s Memory Card', 'Upload/ProductImage/99384.jpg', 'For Mobile\r\nCapacity: 32 GB\r\nMicroSDHC\r\nClass 10\r\nRead Speed: 95 MB/s', 'SEVOP32GMSDHC', '749.00', 0, NULL, '2017-11-17 02:34:19', '2017-11-17 02:34:19'),
(9, 1, 2, 'Back Cover for Motorola Moto E4 Plus  (Shock Proof, Plastic)', 'Upload/ProductImage/94244.jpg', 'Suitable For: Mobile\r\nMaterial: Plastic\r\nTheme: No Theme\r\nType: Back Cover', 'BCMME4P', '254.00', 0, NULL, '2017-11-17 02:36:01', '2017-11-17 02:36:01'),
(10, 1, 2, 'Flat Charge & Sync USB Cable  (Black, 1 Mtr)', 'Upload/ProductImage/81203.jpg', 'Length 1 m\r\nFlat Cable\r\nConnector One: USB 2.0|Connector Two: Micro USB\r\nCable Speed: 480 Mbps\r\nMobile', 'FC&SUSBCD', '199.00', 0, NULL, '2017-11-17 02:37:33', '2017-11-17 02:37:33'),
(11, 1, 2, 'Lenovo PA13000 13000 mAh Power Bank  (White, Lithium-ion)', 'Upload/ProductImage/39210.png', 'Weighs 399 g | Capacity: 13000 mAh\r\nLithium-ion Battery | Micro Connector\r\nPower Source: USB\r\nCharging Cable Included', 'LPA13000mAhPBWL', '1199.00', 0, NULL, '2017-11-17 02:40:28', '2017-11-17 02:40:28'),
(12, 1, 3, 'Casio Smart Outdoor Smartwatch  (Black Strap Regular)', 'Upload/ProductImage/11337.jpg', 'Bluetooth Support\r\nTouchscreen\r\nWater Resistant\r\nFitness & Outdoo', 'CSOSWBSR', '19995.00', 0, NULL, '2017-11-17 02:42:32', '2017-11-17 02:42:32'),
(13, 1, 3, 'Smartwatch with Pedometer, Bluetooth Support and Remote Camera  (Black)', 'Upload/ProductImage/28743.jpg', 'Bluetooth Support\r\nTouchscreen\r\nFitness & Outdoor\r\nMeet the Metronaut MTS003 - a smartwatch that\'ll help you stay updated about your fitness stats and phone\'s notifications on the go, without you having to constantly check your phone. Featuring an in-built pedometer, sedentary reminder function and a sleep monitor, this smartwatch helps you discover a healthier lifestyle.', 'SWwPBSandR', '799.00', 0, NULL, '2017-11-17 02:45:57', '2017-11-17 02:45:57'),
(14, 1, 3, 'Apple Watch Series 1 - 42 mm Space Gray Aluminium Case with Black Sport Band  (Black Strap Medium)', 'Upload/ProductImage/10142.png', 'Dual Core S1P processor for faster performance\r\nTrack your activity and share them with your friends\r\nHeart-Rate Monitoring\r\nGet notifications - read messages, receive/reject calls, calendar etc.\r\nBluetooth Support\r\nWith Call Function\r\nTouchscreen\r\nWater Resistant\r\nNotifier', 'AWA1-42mmSGA', '22900.00', 0, NULL, '2017-11-17 02:47:19', '2017-11-17 02:47:19'),
(15, 1, 5, 'Dell Inspiron Core i5 7th Gen - (4 GB/1 TB HDD/Windows 10 Home/2 GB Graphics) 3567 Notebook  (15.6 inch, Black, 2.24 kg)', 'Upload/ProductImage/2052.jpeg', 'Microsoft Office Home and Student 2016\r\nIntel Core i5 Processor (7th Gen)\r\n4 GB DDR4 RAM\r\n64 bit Windows 10 Operating System\r\n1 TB HDD\r\n15.6 inch Display', 'DICi57thG4GR1TBW10', '39990.00', 0, NULL, '2017-11-17 02:50:31', '2017-11-17 02:50:31'),
(16, 1, 5, 'HP Imprint Core i3 6th Gen - (4 GB/1 TB HDD/DOS) 15Q-BU007TU Laptop  (15.6 inch, Black, 2.1 kg)', 'Upload/ProductImage/48440.jpg', 'Intel Core i3 Processor (6th Gen)\r\n4 GB DDR4 RAM\r\nDOS Operating System\r\n1 TB HDD\r\n15.6 inch Display', 'HPICi36thG4GR1TBHDD&DOS', '27990.00', 0, NULL, '2017-11-17 02:58:21', '2017-11-17 02:58:21'),
(17, 1, 5, 'Lenovo Core i3 6th Gen - (4 GB/1 TB HDD/Windows 10 Home) IP 320E Laptop  (15.6 inch, Black, 2.2 kg)', 'Upload/ProductImage/96006.jpg', '2 x USB 3.0, 1 x USB Type C\r\nFree Pre Loaded MS Office Home & Student 2016\r\nIntel Core i3 Processor (6th Gen)\r\n4 GB DDR4 RAM\r\n64 bit Windows 10 Operating System\r\n1 TB HDD\r\n15.6 inch Display', 'LCi34GR1TBHDD/W10', '31990.00', 0, NULL, '2017-11-17 02:59:47', '2017-11-17 02:59:47'),
(18, 1, 6, 'Canon EOS 1300D DSLR Camera Body with Dual Lens: EF-S 18-55 mm IS II + EF-S 55-250 mm F4 5.6 IS II (16 GB SD Card + Camera Bag)  (Black)', 'Upload/ProductImage/3219.jpg', 'Effective Pixels: 18 MP\r\nSensor Type: CMOS\r\nWiFi Available', 'CEOS13000DCBwDL', '33490.00', 0, NULL, '2017-11-17 03:01:52', '2017-11-17 03:01:52'),
(19, 1, 6, 'Nikon D3400 DSLR Camera Body with Dual Lens: AF-P DX NIKKOR 18-55 mm f/3.5 - 5.6G VR + AF-P DX NIKKOR 70-300 mm f/4.5 - 6.3G ED VR (16 GB SD Card + Camera Bag)  (Black)', 'Upload/ProductImage/94832.jpeg', 'Effective Pixels: 24.2 MP\r\nSensor Type: CMOS\r\nHD, Full HD', 'ND3400DCBwDLAF-p', '37990.00', 0, NULL, '2017-11-17 03:03:38', '2017-11-17 03:03:38'),
(20, 1, 7, 'LG 80cm (32 inch) HD Ready LED Smart TV  (32LJ573D)', 'Upload/ProductImage/59007.png', '20 W Speaker Output\r\n1366 x 768 HD Ready - Great picture quality\r\n60 Hz : Standard refresh rate for blur-free picture quality\r\n2 x HDMI : For set top box and consoles\r\n1 x USB : Get content from USB drives', 'LG80cm32iHDRLED', '23999.00', 0, NULL, '2017-11-17 03:05:17', '2017-11-17 03:05:17'),
(21, 1, 7, 'Sanyo NXT 108.2cm (43 inch) Full HD LED TV  (XT-43S7200F)', 'Upload/ProductImage/40723.jpg', '20 W Speaker Output\r\n1920 x 1080 Full HD - Watch Blu-ray movies at their highest level of detail\r\n60 Hz : Standard refresh rate for blur-free picture quality\r\n3 x HDMI : For set top box, consoles and Blu-ray players\r\n2 x USB : Easily connect your digital camera, camcorder or USB device', 'SNXT43iFHDLED', '24999.00', 0, NULL, '2017-11-17 03:07:20', '2017-11-17 03:07:20'),
(22, 2, 4, 'Oricum Boxer-303 Sneakers  (Black)', 'Upload/ProductImage/53661.jpeg', 'Colour: Black\r\nOuter Material: Canvas', 'OB-303SB', '296.00', 0, NULL, '2017-11-17 03:08:49', '2017-11-17 03:08:49'),
(23, 2, 4, 'Nike REVOLUTION 3 Running Shoes  (Grey)', 'Upload/ProductImage/54549.jpg', 'Colour: Grey\r\nOuter Material: Mesh, Synthetic Leather\r\nClosure: Laced', 'NREV-3RSG', '2805.00', 0, NULL, '2017-11-17 03:10:15', '2017-11-17 03:10:15'),
(24, 2, 4, 'Puma Men black-blue Sports Sandals', 'Upload/ProductImage/28145.jpg', 'Color: Black, Blue\r\nWear: Sports\r\nHeel Height:0 inch\r\nClosure: Velcro', 'PMBSS', '1209.00', 0, NULL, '2017-11-17 03:12:26', '2017-11-17 03:12:26'),
(25, 2, 8, 'Metronaut Solid Men\'s Round Neck Orange T-Shirt', 'Upload/ProductImage/28806.jpg', 'Fabric: Cotton Polyester Blend\r\nSlim Fit Round Neck T-shirt\r\nPattern: Solid\r\nSleeve Type: Narrow Half Sleeve\r\nServices\r\n30 Days Refund/Exchange?\r\nCash on Delivery available?\r\nSeller', 'MSmenRneckOT-S', '329.00', 0, NULL, '2017-11-17 03:15:14', '2017-11-17 03:15:14'),
(26, 2, 8, 'Katso Solid Men\'s Hooded Black T-Shirt', 'Upload/ProductImage/29420.jpg', 'Fabric: Cotton\r\nSlim Fit Hooded T-shirt\r\nPattern: Solid\r\nFull Sleeve', 'KSmenHooded-B-T-S', '350.00', 0, NULL, '2017-11-17 03:16:37', '2017-11-17 03:16:37'),
(27, 2, 8, 'Billion PerfectFit Solid Men Round Neck Grey, White T-Shirt  (Pack of 3', 'Upload/ProductImage/19758.jpeg', 'Fabric: Cotton\r\nSlim Fit Round Neck T-shirt\r\nPattern: Solid\r\nSleeve Type: Narrow Full Sleeve', 'BPSolidG-W-B-T-S', '960.00', 0, NULL, '2017-11-17 03:18:21', '2017-11-17 03:18:21'),
(28, 2, 9, 'Metronaut Slim Men Light Blue Jeans', 'Upload/ProductImage/61363.jpg', 'Fit: Slim\r\nFabric: Cotton\r\nMid Rise Jeans\r\nMild Distress', 'MS-Men-LBlue-J', '1399.00', 0, NULL, '2017-11-17 03:20:04', '2017-11-17 03:20:04'),
(29, 2, 9, 'Metronaut Slim Men Dark Blue Jeans', 'Upload/ProductImage/79899.jpeg', 'Fit: Slim\r\nFabric: Cotton\r\nMid Rise Jeans\r\nMild Distress', 'MS-Men-DBlue-J', '839.00', 0, NULL, '2017-11-17 03:21:50', '2017-11-17 03:21:50'),
(30, 2, 9, 'Flying Machine Slim Men Blue Jeans', 'Upload/ProductImage/20544.jpeg', 'Fit: Slim\r\nFabric: Cotton Stretch\r\nHeavy Fade Mid Rise Jeans\r\nHigh Distress', 'FMS-Men-BlueJ', '2299.00', 0, NULL, '2017-11-17 03:23:11', '2017-11-17 03:23:11'),
(31, 2, 10, 'Gag Full Sleeve Solid Men & Women Sports Jacket', 'Upload/ProductImage/35271.jpg', 'Pattern: Solid\r\nSuitable For: Western Wear\r\nType: Sports Jacket', 'GFSS-Men-S-J', '499.00', 0, NULL, '2017-11-17 03:24:40', '2017-11-17 03:24:40'),
(32, 2, 11, 'Fastrack NG3120SL01C Bare Basic Watch - For Men', 'Upload/ProductImage/55680.jpg', 'Watch Movement: Quartz\r\nWater Resistant (50 m)\r\nDisplay Type: Analog\r\nStrap: Brown, Leather', 'F-ND3120-BBW-Men', '1305.00', 0, NULL, '2017-11-17 03:27:19', '2017-11-17 03:27:19'),
(33, 2, 11, 'Timex T49994 Watch - For Men', 'Upload/ProductImage/53359.jpg', 'Watch Movement: Quartz\r\nWater Resistant (50 m)\r\nDisplay Type: Analog\r\nStrap: Resin\r\nScratch Resistant', 'T-T49994-W-Men', '5772.00', 0, NULL, '2017-11-17 03:28:34', '2017-11-17 03:28:34'),
(34, 2, 11, 'Titan 1730SL02 Watch - For Men', 'Upload/ProductImage/74619.jpg', 'Water Resistant (50 m)\r\nDisplay Type: Analog\r\nStrap: Brown\r\nDate Display Available\r\nServices\r\n10 Days Replacement Policy?\r\nCash on Delivery available?\r\nSeller', 'T-1730SL02-Men', '2495.00', 0, NULL, '2017-11-17 03:29:48', '2017-11-17 03:29:48'),
(35, 3, 12, 'Christy World Full Sleeve Solid Women\'s Sports Jacket', 'Upload/ProductImage/31558.jpg', 'Pattern: Solid\r\nSuitable For: Western Wear\r\nHooded\r\nType: Sports Jacket', 'CWSS-Women-sJ', '531.00', 0, NULL, '2017-11-17 03:31:26', '2017-11-17 03:31:26'),
(36, 3, 13, 'Fourgee Slim Women\'s Blue Jeans', 'Upload/ProductImage/4937.jpg', 'Fit: Slim\r\nFabric: DENIM\r\nMid Rise Jeans', 'FS-Women-Blue-J', '669.00', 0, NULL, '2017-11-17 03:33:16', '2017-11-17 03:33:16'),
(37, 3, 14, 'Klamotten Women\'s Robe  (Dark Blue)', 'Upload/ProductImage/81070.jpg', 'Type: Robe\r\nPattern: Solid\r\nFabric: Satin', 'K-Women-R', '349.00', 0, NULL, '2017-11-17 03:36:17', '2017-11-17 03:36:17'),
(38, 3, 15, 'Ishin Synthetic Printed Salwar Suit Dupatta Material  (Un-stitched)', 'Upload/ProductImage/13446.jpg', 'Type: Salwar Suit Dupatta Material\r\nFabric: Synthetic\r\nPattern: Printed\r\nColor: Multicolor\r\nWith Dupatta\r\nPackage Contains:1 Top, 1 Bottom & 1 Duppatta (Unstitched)', 'ISPSSDM', '399.00', 0, NULL, '2017-11-17 03:37:57', '2017-11-17 03:37:57'),
(39, 3, 16, '2Go Solid Women\'s Round Neck T-Shirt', 'Upload/ProductImage/6999.jpg', 'Fabric: Polyester\r\nSlim Fit Round Neck T-shirt\r\nPattern: Solid\r\nShort Sleeve', '2GOS-Women-RNG', '599.00', 0, NULL, '2017-11-17 03:39:39', '2017-11-17 03:39:39'),
(40, 3, 17, 'Malabar Gold and Diamonds Yellow Gold 22kt Stud Earring', 'Upload/ProductImage/69434.jpg', 'Gold Purity: 22k', 'MG&DYG22kt', '11385.00', 0, NULL, '2017-11-17 03:41:22', '2017-11-17 03:41:22'),
(41, 3, 18, 'Jovees Ayurveda Tea Tree & Clove Anti Acne Antiseptic Face Pack (Pack of 2)  (240 g)', 'Upload/ProductImage/94128.jpg', 'Ideal For: Women\r\nForm: Cream\r\nFor All Skin Types', 'JATT&CAAA', '351.00', 0, NULL, '2017-11-17 03:42:49', '2017-11-17 03:42:49'),
(42, 4, 28, 'Funskool Play-Doh Case of Colours', 'Upload/ProductImage/65057.jpg', 'Type: Clay Art & Moulding\r\nIdeal For: Boys, Girls', 'FP-DCofColor', '257.00', 0, NULL, '2017-11-17 03:44:30', '2017-11-17 03:44:30'),
(43, 4, 28, 'Hasbro Electronic Battleship Board Game', 'Upload/ProductImage/46590.jpg', 'Board Game Accessories\r\nMaterial: Plastic\r\nAge Group: 96 to 1200 Months\r\nCreativity & Imagination', 'HEBB-Game', '1577.00', 0, NULL, '2017-11-17 03:45:31', '2017-11-17 03:45:31'),
(44, 5, 29, 'Leo Natura Eco5 L Pressure Cooker  (Aluminium)', 'Upload/ProductImage/46495.jpg', 'Pack of: 1\r\nMaterial: Aluminium\r\nLid Type: Outer Lid\r\nColor: Silver\r\nCertification: ISI Certified', 'LNE-5L-PC', '459.00', 0, NULL, '2017-11-17 03:47:16', '2017-11-17 03:47:16'),
(45, 5, 30, 'Ace Camera Lens Shaped with Cookie Lid Coffee Tea Stainless Steel Mug  (250 ml)', 'Upload/ProductImage/69676.jpeg', 'Mug\r\nColor: Black\r\nStainless Steel\r\nTheme: Solids\r\nCapacity: 250 ml', 'ACLSwCLC-tes', '374.00', 0, NULL, '2017-11-17 03:48:50', '2017-11-17 03:48:50'),
(46, 5, 31, 'E\'loisa Serving Bowl with a unique floral design - Set of 3-PC-237 - 1100 ml Ceramic Grocery Container  (Pack of 3, Multicolor', 'Upload/ProductImage/36728.jpg', 'Grocery Container\r\nMaterial: Ceramic', 'ESB-w-UFD', '999.00', 0, NULL, '2017-11-17 03:50:16', '2017-11-17 03:50:16'),
(47, 6, 32, 'The Immortals of Meluha  (English, Paperback, Amish)', 'Upload/ProductImage/2595.jpg', 'Language: English\r\nBinding: Paperback\r\nPublisher: Westland\r\nGenre: Indian Writing\r\nISBN: 9789380658742, 9380658745\r\nEdition: 2010\r\nPages: 412', 'TI-of-M-Book', '158.00', 0, NULL, '2017-11-17 03:53:16', '2017-11-17 03:53:16'),
(48, 6, 32, 'Discovery of India  (English, Paperback, Jawaharlal Nehru)', 'Upload/ProductImage/9651.jpg', 'Language: English\r\nBinding: Paperback\r\nPublisher: Penguin Books\r\nISBN: 9780143031031, 0143031031\r\nEdition: 1stEdition, 2004\r\nPages: 642', 'D-of-I-EPJ', '516.00', 0, NULL, '2017-11-17 03:54:23', '2019-12-28 08:09:15'),
(49, 3, 12, 'brijesh prod', 'Upload/ProductImage/32595.jpg', 'hh', '1212121', '24500.00', 0, NULL, '2019-12-25 13:50:16', '2019-12-25 13:50:16');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `category_id`, `sub_category_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Mobiles', '2017-11-15 12:31:16', '2017-11-15 12:31:16'),
(2, 1, 'Mobile Accessories', '2017-11-15 12:41:05', '2017-11-15 12:41:05'),
(3, 1, 'Smart Wearable Tech', '2017-11-15 12:42:34', '2017-11-15 12:42:34'),
(4, 2, 'Footwear', '2017-11-15 13:08:45', '2017-11-15 13:08:45'),
(5, 1, 'Laptops', '2017-11-15 13:09:32', '2017-11-15 13:09:32'),
(6, 1, 'Camera', '2017-11-15 13:10:02', '2017-11-15 13:10:02'),
(7, 1, 'Televisions', '2017-11-15 13:10:27', '2017-11-15 13:10:27'),
(8, 2, 'Top wear', '2017-11-15 13:10:49', '2017-11-15 13:10:49'),
(9, 2, 'Bottom wear', '2017-11-15 13:11:07', '2017-11-15 13:11:07'),
(10, 2, 'Sports wear', '2017-11-15 13:11:44', '2017-11-15 13:11:44'),
(11, 2, 'Watches', '2017-11-15 13:12:24', '2017-11-15 13:12:24'),
(12, 3, 'Winter & Seasonal Wear', '2017-11-15 13:13:00', '2017-11-15 13:13:00'),
(13, 3, 'Western Wear', '2017-11-15 13:13:44', '2017-11-15 13:13:44'),
(14, 3, 'Lingerie & Sleepwear', '2017-11-15 13:14:13', '2017-11-15 13:14:13'),
(15, 3, 'Ethnic Wear', '2017-11-15 13:14:33', '2017-11-15 13:14:33'),
(16, 3, 'Sports wear', '2017-11-15 13:15:48', '2017-11-15 13:15:48'),
(17, 3, 'Jewellery', '2017-11-15 13:16:27', '2017-11-15 13:16:27'),
(18, 3, 'Beauty & Grooming', '2017-11-15 13:16:49', '2017-11-15 13:16:49'),
(19, 4, 'Boys\' Clothing', '2017-11-15 13:17:18', '2017-11-15 13:17:18'),
(20, 4, 'Kids Clothing', '2017-11-15 13:17:37', '2017-11-15 13:17:37'),
(21, 4, 'Girls\' Clothing', '2017-11-15 13:18:04', '2017-11-15 13:18:04'),
(22, 4, 'Baby Boy Clothing', '2017-11-15 13:18:41', '2017-11-15 13:18:41'),
(23, 4, 'Baby Girl Clothing', '2017-11-15 13:19:03', '2017-11-15 13:19:03'),
(24, 4, 'Kids Footwear', '2017-11-15 13:19:29', '2017-11-15 13:19:29'),
(25, 4, 'Girls\' Footwear', '2017-11-15 13:20:21', '2017-11-15 13:20:21'),
(26, 4, 'boys\' Footwear', '2017-11-15 13:20:42', '2017-11-15 13:20:42'),
(27, 4, 'Baby Footwear', '2017-11-15 13:21:02', '2017-11-15 13:21:02'),
(28, 4, 'Toys', '2017-11-15 13:21:20', '2017-11-15 13:21:20'),
(29, 5, 'Kitchen & Dining', '2017-11-15 13:21:43', '2017-11-15 13:21:43'),
(30, 5, 'Dining & Serving', '2017-11-15 13:22:00', '2017-11-15 13:22:00'),
(31, 5, 'Kitchen Storage', '2017-11-15 13:22:18', '2017-11-15 13:22:18'),
(32, 6, 'Books', '2017-11-15 13:22:33', '2017-11-15 13:22:33');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
