<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('categoty_id');
            $table->integer('sub_categoty_id');
            $table->string('product_name',500);
            $table->string('product_image',100);
            $table->longText('description');
            $table->string('product_code',20);
            $table->decimal('product_price',18,2);
            $table->integer('is_offer');
            $table->decimal('product_special_price',18,2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
