<?php
					$i = 1;
					?>
					@foreach($product as $product_val)
					
					<div class="col-md-4 top_brand_left">
						<div class="hover14 column">
							<div class="agile_top_brand_left_grid">
								<div class="agile_top_brand_left_grid_pos">
									<img src="images/offer.png" alt=" " class="img-responsive">
								</div>
								<div class="agile_top_brand_left_grid1">
									<figure>
										<div class="snipcart-item block">
											<div class="snipcart-thumb">
												<a href="{{ URL::to('product-detail',$product_val->id) }}"><img title=" " alt=" " src="{{ $product_val->product_image }}" height="150px" width="150px"></a>		
												<p>{{ substr( $product_val->product_name,0,15) }}</p>
												<h4><i class="fa fa-inr" aria-hidden="true"></i> {{ $product_val->product_price }} <span>$55.00</span></h4>
											</div>
											<div class="snipcart-details top_brand_home_details">
												<form action="#" method="post">
													<fieldset>
														<input type="hidden" name="cmd" value="_cart">
														<input type="hidden" name="add" value="1">
														<input type="hidden" name="business" value=" ">
														<input type="hidden" name="item_name" value="Fortune Sunflower Oil">
														<input type="hidden" name="amount" value="35.99">
														<input type="hidden" name="discount_amount" value="1.00">
														<input type="hidden" name="currency_code" value="USD">
														<input type="hidden" name="return" value=" ">
														<input type="hidden" name="cancel_return" value=" ">
														<input type="submit" name="submit" value="Add to cart" class="button">
													</fieldset>
												</form>
											</div>
										</div>
									</figure>
								</div>
							</div>
						</div>
					</div>
					@if($i == 3 OR $i==6 OR $i==9 )
						<div class="clearfix"> </div>
						<br>
					@endif
					<?php $i++ ?>
					@endforeach
					