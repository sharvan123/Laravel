@extends('master_page')

@section('title', 'User Account Page')

@section('content')
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Login Page</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- login -->
	<div class="login">
		<div class="container">
			<h2>My Account</h2>
			<br>
			@if(!empty(session('password')))
                <div class="alert alert-block alert-success fade in">
                  <button data-dismiss="alert" class="close close-sm" type="button">
                      <i class="icon-remove"></i>
                  </button>
                  {{ session('password') }}
                </div>
            @endif
			<a href="">My Profile</a><br>
			<a href="">My Order</a><br>
			<a href="">Change Password</a><br>
			<a href="">Logout</a><br>
		</div>
	</div>
@endsection

@section('script')

@endsection