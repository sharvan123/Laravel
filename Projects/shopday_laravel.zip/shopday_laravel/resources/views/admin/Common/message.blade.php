@if(!empty(session('success')))
	<div class="alert alert-success fade in">
	  <button data-dismiss="alert" class="close close-sm" type="button">
	      <i class="icon-remove"></i>
	  </button>
	  <strong>{{ session('success')}}</strong>
	</div>  
@endif