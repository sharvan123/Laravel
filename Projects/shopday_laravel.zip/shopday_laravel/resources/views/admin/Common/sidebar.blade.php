      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                 
			          <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Banners</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ route('banner.create') }}">Add Banner</a></li>                          
                        <li><a class="" href="{{ URL::to('admin/banner') }}">Manage Banners</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Product Category</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ route('category.create') }}">Add Category</a></li>                          
                        <li><a class="" href="{{ URL::to('admin/category') }}">Manage Category</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Sub Category</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ route('sub-category.create') }}">Add Sub Category</a></li>                          
                        <li><a class="" href="{{ URL::to('admin/sub-category') }}">Manage Sub Category</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Product</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ route('product.create') }}">Add Product</a></li>                          
                        <li><a class="" href="{{ URL::to('admin/product') }}">Manage Product</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Enquiry</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ URL::to('admin/enquiry') }}">Manage Enquiry</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;" class="">
                        <span>Customer</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
                    <ul class="sub">
                        <li><a class="" href="{{ URL::to('admin/customer') }}">Manage Customer</a></li>
                    </ul>
                </li>       
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
