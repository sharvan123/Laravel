
    <!-- javascripts -->
    {!! Html::script('admin/js/jquery.js') !!}
	{!! Html::script('admin/js/jquery-ui-1.10.4.min.js') !!}
    {!! Html::script('admin/js/jquery-1.8.3.min.js') !!}
    {!! Html::script('admin/js/jquery-ui-1.9.2.custom.min.js') !!}
    <!-- bootstrap -->
    {!! Html::script('admin/js/bootstrap.min.js') !!}
    <!-- nice scroll -->
    {!! Html::script('admin/js/jquery.scrollTo.min.js') !!}
    {!! Html::script('admin/js/jquery.nicescroll.js') !!}
    <!-- charts scripts -->
    {!! Html::script('admin/assets/jquery-knob/js/jquery.knob.js') !!}
    {!! Html::script('admin/js/jquery.sparkline.js') !!}
    {!! Html::script('admin/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js') !!}
    {!! Html::script('admin/js/owl.carousel.js') !!}
    <!-- jQuery full calendar -->
    {!! Html::script('admin/js/fullcalendar.min.js') !!}Calendar -->
	{!! Html::script('admin/assets/fullcalendar/fullcalendar/fullcalendar.js') !!}
    <!--script for this page only-->
    {!! Html::script('admin/js/calendar-custom.js') !!}
	{!! Html::script('admin/js/jquery.rateit.min.js') !!}
    <!-- custom select -->
    {!! Html::script('admin/js/jquery.customSelect.min.js') !!}
	{!! Html::script('admin/assets/chart-master/Chart.js') !!}
   
    <!--custome script for all page-->
    {!! Html::script('admin/js/scripts.js') !!}
    <!-- custom script for this page-->
    {!! Html::script('admin/js/sparkline-chart.js') !!}
    {!! Html::script('admin/js/easy-pie-chart.js') !!}
	{!! Html::script('admin/js/jquery-jvectormap-1.2.2.min.js') !!}
	{!! Html::script('admin/js/jquery-jvectormap-world-mill-en.js') !!}
	{!! Html::script('admin/js/xcharts.min.js') !!}
	{!! Html::script('admin/js/jquery.autosize.min.js') !!}
	{!! Html::script('admin/js/jquery.placeholder.min.js') !!}
	{!! Html::script('admin/js/gdp-data.js') !!}
	{!! Html::script('admin/js/morris.min.js') !!}
	{!! Html::script('admin/js/sparklines.js') !!}
	{!! Html::script('admin/js/charts.js') !!}
	{!! Html::script('admin/js/jquery.slimscroll.min.js') !!}
  <script>

      //knob
      $(function() {
        $(".knob").knob({
          'draw' : function () { 
            $(this.i).val(this.cv + '%')
          }
        })
      });

      //carousel
      $(document).ready(function() {
          $("#owl-slider").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });
	  
	  /* ---------- Map ---------- */
	$(function(){
	  $('#map').vectorMap({
	    map: 'world_mill_en',
	    series: {
	      regions: [{
	        values: gdpData,
	        scale: ['#000', '#000'],
	        normalizeFunction: 'polynomial'
	      }]
	    },
		backgroundColor: '#eef3f7',
	    onLabelShow: function(e, el, code){
	      el.html(el.html()+' (GDP - '+gdpData[code]+')');
	    }
	  });
	});

  </script>

  </body>
</html>