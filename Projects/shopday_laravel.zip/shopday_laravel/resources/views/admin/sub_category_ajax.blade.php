<label for='sub_category_id' class='control-label col-lg-3'>Select Sub Category <span class='text-danger'>*</span></label>
                                          <div class='col-lg-4'>
                                              <select class='form-control' name='sub_category_id'>
                                                <option value=''> --Select Category-- </option>
                                                @foreach($sub_category as $key => $sub_category_val)
                                                <option value='{{ $key }}'>{{ $sub_category_val }}</option>
                                                @endforeach
                                              </select>
                                              @if(!empty($errors->has('sub_category_id'))) <strong class='text-danger'>{{ $errors->first('sub_category_id')}} </strong> @endif
                                          </div>