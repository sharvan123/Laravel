<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Shop Day Admin Login">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Shop Day Admin Login</title>

    <!-- Bootstrap CSS -->    
    {!! Html::style('admin/css/bootstrap.min.css') !!} 
    <!-- bootstrap theme -->
    {!! Html::style('admin/css/bootstrap-theme.css') !!} 
    <!--external css-->
    <!-- font icon -->
    {!! Html::style('admin/css/elegant-icons-style.css') !!} 
    {!! Html::style('admin/css/font-awesome.min.css') !!}
    <!-- Custom styles -->
    {!! Html::style('admin/css/style.css') !!} 
    {!! Html::style('admin/css/style-responsive.css') !!}

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="login-img3-body">

    <div class="container">
      <form class="login-form" action="{{ URL::to('admin/login_check')}}" method="POST">
        {{ csrf_field() }} 

        <div class="login-wrap">
            <p class="login-img"><i class="icon_lock_alt"></i></p>
            @if(!empty(session('error')))
                <div class="alert alert-block alert-danger fade in">
                  <button data-dismiss="alert" class="close close-sm" type="button">
                      <i class="icon-remove"></i>
                  </button>
                  {{ session('error') }}
                </div>
            @endif
            @if(!empty($errors->has('email'))) <span class="text-danger">{{ $errors->first('email') }}</span>@endif
            <div class="input-group">
              <span class="input-group-addon"><i class="icon_profile"></i></span>
              <input type="text" name="email" id="email" class="form-control" placeholder="Email" autofocus>
            </div>
            @if(!empty($errors->has('password'))) <span class="text-danger">{{ $errors->first('password') }}</span>@endif
            <div class="input-group">
                <span class="input-group-addon"><i class="icon_key_alt"></i></span>
                <input type="password" name="password" id="password" class="form-control" placeholder="Password">
            </div>
            <label class="checkbox">
                <input type="checkbox" value="remember-me"> Remember me
                <span class="pull-right"> <a href="#"> Forgot Password?</a></span>
            </label>
            <button class="btn btn-primary btn-lg btn-block" type="submit">Login</button>
            
        </div>
      </form>
    <div class="text-right">
            <div class="credits">
                <!-- 
                    All the links in the footer should remain intact. 
                    You can delete the links only if you purchased the pro version.
                    Licensing information: https://bootstrapmade.com/license/
                    Purchase the pro version form: https://bootstrapmade.com/buy/?theme=NiceAdmin
                -->
                <a href="javascript:void(0);">Brijesh Pandey</a>
            </div>
        </div>
    </div>


  </body>
</html>
