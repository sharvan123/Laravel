@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Show Customer <a href="{{ URL::to('admin/customer')}}" class="btn btn-primary pull-right">Manage Customer</a></h3>
                </div>
              </div>
              @include('admin/Common/message')
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th width="30%">Name</th>
                                 <td width="70%"> {{ $customer->name }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Email</th>
                                 <td width="70%"> {{ $customer->email }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Mobile</th>
                                 <td width="70%"> {{ $customer->mobile }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Address</th>
                                 <td width="70%"> {{ $customer->address }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">City</th>
                                 <td width="70%"> {{ $customer->city }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">State</th>
                                 <td width="70%"> {{ $customer->state }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Country</th>
                                 <td width="70%"> {{ $customer->country }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Deceived Date</th>
                                 <td width="70%"> {{ date("d-M-Y", strtotime( $customer->created_at )) }}</td>
                              </tr>
                        </table>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')