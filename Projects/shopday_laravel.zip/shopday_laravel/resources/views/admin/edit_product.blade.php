@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Edit Product <a href="{{ URL::to('admin/product')}}" class="btn btn-primary pull-right">Manage Product</a></h3>
                </div>
              </div>  
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             <span class="pull-right"> Marked with (<strong class="text-danger">*</strong>) are Mandatory</span>
                          </header>
                          <div class="panel-body">
                              <div class="form">
                                  <form class="form-validate form-horizontal " id="register_form" method="POST" action="{{ route('product.update',$product->id) }}" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    {{ method_field('PUT') }}
                                      <div class="form-group ">
                                          <label for="category_id" class="control-label col-lg-3">Select Category <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <select class="form-control" name="category_id">
                                                <option value=""> --Select Category-- </option>
                                                @foreach($category as $key => $category_val)
                                                <option value="{{ $key }}" {{ $key == $product->category_id? 'selected' : ''}}>{{ $category_val }}</option>
                                                @endforeach
                                              </select>
                                              @if(!empty($errors->has('category_id'))) <strong class="text-danger">{{ $errors->first('category_id')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="sub_category_id" class="control-label col-lg-3">Select Sub Category <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <select class="form-control" name="sub_category_id">
                                                <option value=""> --Select Category-- </option>
                                                @foreach($sub_category as $key => $sub_category_val)
                                                <option value="{{ $key }}" {{ $key == $product->sub_category_id? 'selected' : ''}}>{{ $sub_category_val }}</option>
                                                @endforeach
                                              </select>
                                              @if(!empty($errors->has('sub_category_id'))) <strong class="text-danger">{{ $errors->first('sub_category_id')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="product_name" class="control-label col-lg-3">Product Name <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="product_name" name="product_name" type="text" value="{{ $product->product_name}}" />
                                              @if(!empty($errors->has('product_name'))) <strong class="text-danger">{{ $errors->first('product_name')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="product_image" class="control-label col-lg-3">Product Image <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="product_image" name="product_image" type="file" />
                                              @if(!empty($errors->has('product_image'))) <strong class="text-danger">{{ $errors->first('product_image')}} </strong> @endif
                                              @if(!empty($product->product_image))
                                                <br>
                                                <img src="../../../{{ $product->product_image }}" width="150" height="150">
                                              @endif
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <label class="control-label col-sm-3">Description<span class="text-danger">*</span></label>
                                          <div class="col-sm-8">
                                              <textarea class="form-control" name="description" rows="6">{{ $product->description }}</textarea>
                                              @if(!empty($errors->has('description'))) <strong class="text-danger">{{ $errors->first('description')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="product_code" class="control-label col-lg-3">Product Code <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="product_code" name="product_code" type="text" value="{{ $product->product_code}}" />
                                              @if(!empty($errors->has('product_code'))) <strong class="text-danger">{{ $errors->first('product_code')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="product_price" class="control-label col-lg-3">Product Price <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="product_price" name="product_price" type="text" value="{{ $product->product_price }}" />
                                              @if(!empty($errors->has('product_price'))) <strong class="text-danger">{{ $errors->first('product_price')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-3 pull-right">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')
