@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Show Enquiry <a href="{{ URL::to('admin/enquiry')}}" class="btn btn-primary pull-right">Manage Enquiry</a></h3>
                </div>
              </div>
              @include('admin/Common/message')
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th width="30%">Name</th>
                                 <td width="70%"> {{ $enquiry->name }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Email</th>
                                 <td width="70%"> {{ $enquiry->email }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Message</th>
                                 <td width="70%"> {{ $enquiry->comment }}</td>
                              </tr>
                              <tr>
                                 <th width="30%">Deceived Date</th>
                                 <td width="70%"> {{ date("d-M-Y", strtotime( $enquiry->created_at )) }}</td>
                              </tr>
                        </table>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')