@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Manage Enquiry</h3>
                </div>
              </div>
              @include('admin/Common/message')
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th width="30%">Name</th>
                                 <th width="30%"> Email</th>
                                 <th width="20%"> Date</th>
                                 <th width="20%"> Action</th>
                              </tr>
                              @if(count($enquiry) > 0)
                              @foreach($enquiry as $enquiry_val)
                              <tr>
                                 <td>{{ $enquiry_val->name }}</td>
                                 <td>{{ $enquiry_val->email }}</td>
                                 <td>{{ date('d-M-Y',strtotime($enquiry_val->created_at)) }}</td>
                                 <td>
                                  <div class="btn-group">
                                      <a class="btn btn-primary" href="{{ route('enquiry.show',$enquiry_val->id) }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                      <a class="btn btn-danger" href="{{ URL::to('admin/enquiry-delete',$enquiry_val->id) }}"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                  </div>
                                  </td>
                              </tr>
                              @endforeach
                              @else
                                <div><center>Sorry no data founds..</center></div>
                              @endif
                           </tbody>
                        </table>
                        <div> <center>{{ $enquiry->links() }}</center></div>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')