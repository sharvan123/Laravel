@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Add Sub Category <a href="{{ URL::to('admin/sub-category')}}" class="btn btn-primary pull-right">Manage Sub Category</a></h3>
                </div>
              </div>  
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             <span class="pull-right"> Marked with (<strong class="text-danger">*</strong>) are Mandatory</span>
                          </header>
                          <div class="panel-body">
                              <div class="form">
                                  <form class="form-validate form-horizontal " id="register_form" method="POST" action="{{ route('sub-category.store') }}" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                      <div class="form-group ">
                                          <label for="category_id" class="control-label col-lg-3">Select Category <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <select class="form-control" name="category_id">
                                                <option value=""> --Select Category-- </option>
                                                @foreach($category as $key => $category_val)
                                                <option value="{{ $key }}">{{ $category_val }}</option>
                                                @endforeach
                                              </select>
                                              @if(!empty($errors->has('category_id'))) <strong class="text-danger">{{ $errors->first('category_id')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="sub_category_name" class="control-label col-lg-3">Sub Category Name <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="sub_category_name" name="sub_category_name" type="text" />
                                              @if(!empty($errors->has('sub_category_name'))) <strong class="text-danger">{{ $errors->first('sub_category_name')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-3 pull-right">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')