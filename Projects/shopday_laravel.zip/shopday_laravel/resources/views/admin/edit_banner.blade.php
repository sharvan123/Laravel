@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Edit Banner <a href="{{ URL::to('admin/banner')}}" class="btn btn-primary pull-right">Manage Banners</a></h3>
                </div>
              </div>  
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             <span class="pull-right"> Marked with (<strong class="text-danger">*</strong>) are Mandatory</span>
                          </header>
                          <div class="panel-body">
                              <div class="form">
                                  <form class="form-validate form-horizontal " id="register_form" method="POST" action="{{ route('banner.update',$banners->id) }}" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    {{ method_field('PUT') }}
                                      <div class="form-group ">
                                          <label for="fullname" class="control-label col-lg-3">Caption <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="caption" name="caption" type="text" value="{{ $banners->caption }}" />
                                              @if(!empty($errors->has('caption'))) <strong class="text-danger">{{ $errors->first('caption')}} </strong> @endif
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="url" class="control-label col-lg-3">Banner Link <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="url" name="url" type="url" value="{{ $banners->banner_link }}" />
                                          </div>
                                      </div>
                                      <div class="form-group ">
                                          <label for="banner" class="control-label col-lg-3">Banner <span class="text-danger">*</span></label>
                                          <div class="col-lg-4">
                                              <input class=" form-control" id="banner" name="banner" type="file" />
                                              @if(!empty($errors->has('banner'))) <strong class="text-danger">{{ $errors->first('banner')}} </strong> @endif

                                              @if(!empty($banners->banner))
                                              <br>
                                              <img src="../../../{{ $banners->banner }}" height="110px" width="300px">
                                              @endif
                                          </div>
                                      </div>
                                      <div class="form-group">
                                          <div class="col-lg-3 pull-right">
                                              <button class="btn btn-primary" type="submit">Save</button>
                                          </div>
                                      </div>
                                  </form>
                              </div>
                          </div>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')