@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Manage Category <a href="{{ route('category.create')}}" class="btn btn-primary pull-right">Add Category</a></h3>
                </div>
              </div>
              @include('admin/Common/message')
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th width="80%"> Category Name</th>
                                 <th> Action</th>
                              </tr>
                              @if(count($category) > 0)
                              @foreach($category as $category_val)
                              <tr>
                                 <td>{{ $category_val->category_name }}</td>
                                 <td>
                                  <div class="btn-group">
                                      <a class="btn btn-success" href="{{ route('category.edit',$category_val->id) }}"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                      <a class="btn btn-danger" href="{{ URL::to('admin/category-delete',$category_val->id) }}"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                  </div>
                                  </td>
                              </tr>
                              @endforeach
                              @else
                                <div><center>Sorry no data founds..</center></div>
                              @endif
                           </tbody>
                        </table>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')