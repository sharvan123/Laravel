@include('admin/Common/header')
@include('admin/Common/sidebar')
      <section id="main-content">
          <section class="wrapper" style="min-height: 600px;">            
              <!--overview start-->
              <div class="row">
                <div class="col-lg-12">
                  <h3 class="page-header"><i class="fa fa-laptop"></i> Manage Products <a href="{{ route('product.create')}}" class="btn btn-primary pull-right">Add product</a></h3>
                </div>
              </div>
              @include('admin/Common/message')
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <table class="table table-striped table-advance table-hover">
                           <tbody>
                              <tr>
                                 <th> Product Name</th>
                                 <th> Image</th>
                                 <th> Category</th>
                                 <th> Sub Category</th>
                                 <th> Action</th>
                              </tr>
                              @foreach($product as $product_val)
                              <tr>
                                 <td>{{ $product_val->product_name }}</td>
                                 <td><img src="../{{ $product_val->product_image }}" height="150px" width="150px"></td>
                                 <td>{{ $product_val->category_name }}</td>
                                 <td>{{ $product_val->sub_category_name }}</td>
                                 <td>
                                  <div class="btn-group">
                                      <a class="btn btn-success" href="{{ route('product.edit',$product_val->id) }}"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                      <a class="btn btn-danger" href="{{ URL::to('admin/product-delete',$product_val->id) }}"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                  </div>
                                  </td>
                              </tr>
                              @endforeach
                           </tbody>
                        </table>
                        <div> <center>{{ $product->links() }}</center></div>
                      </section>
                  </div>
              </div>
          </section>
          <div class="text-right">
          <div class="credits dark-bg ">
                Brijesh Pandey &nbsp;
            </div>
        </div>
      </section>              
@include('admin/Common/footer')