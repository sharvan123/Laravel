@extends('master_page')

@section('title', 'User Login Page')

@section('content')
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Login Page</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!-- login -->
	<div class="login">
		<div class="container">
			<h2>Login Form</h2>
		
			<div class="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
				@if(!empty(session('error')))
	                <div class="alert alert-block alert-danger fade in">
	                  <button data-dismiss="alert" class="close close-sm" type="button">
	                      <i class="icon-remove"></i>
	                  </button>
	                  {{ session('error') }}
	                </div>
	            @endif
				<form action="{{ URL::to('login_check')}}" method="POST">
					{{ csrf_field() }}
					<input type="email" name="email" id="email" placeholder="Email Address">
					@if(!empty($errors->has('email'))) <span class="text-danger">{{ $errors->first('email') }} </span><br> @endif<br>
					<input type="password" name="password" id="password" placeholder="Password">
					@if(!empty($errors->has('password')))	<span class="text-danger">{{ $errors->first('password') }} </span><br> @endif
					<div class="forgot">
						<a href="#">Forgot Password?</a>
					</div>
					<input type="submit" value="Login">
				</form>
			</div>
			<h4>For New People</h4>
			<p><a href="{{ URL::to('register')}}">Register Here</a> (Or) go back to <a href="{{ URL::to('/') }}">Home<span class="glyphicon glyphicon-menu-right" aria-hidden="true"></span></a></p>
		</div>
	</div>
@endsection

@section('script')

@endsection