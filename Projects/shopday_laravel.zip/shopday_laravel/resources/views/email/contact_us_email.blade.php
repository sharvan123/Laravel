<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div style="width: 900px; margin:auto; border: 1px solid #CECECE;">
  <div style="font-family:'Brandon',Helvetica,Arial!important;font-size:16px;color:#30373b;background-color:#fff; margin: 25px;">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr height="80" valign="top" >
        <td><table width="100%" border="0">
            <tr style="background-color:#FFF;">
             <td><h1 style="color: #fe9126;">Shop Day</h1></td>
            </tr>
            <tr>
              <td bgcolor="#fe9126" style="text-align:right;font-family:Verdana;font-size:18px;color:#FFF;text-decoration:none;text-indent:10px;height: 25px;"><b>Shop Day Enquiry Received</b>&nbsp;</td>
            </tr>
          </table></td>
      </tr>
        <tr><td style="padding:20px;"><table width="100%" cellspacing="0" cellpadding="6" style="font-family: Calibri, sans-serif;  font-size:90%; color:#000; margin:0px 0px 0px 0px; border-color:#ccc; border-width: 0px 0px 1px 1px; border-style: solid; padding: 0px;">
              <tbody>
             <tr>
                <td width="50%" valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">Name :</td>
                 <td width="50%" valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">{{ $name }}</td>
               </tr>
            <tr>
                <td valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">Email :</td>
                <td valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">{{ $email }}</td>
            </tr>
            <tr>
                <td valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">Message :</td>
                <td valign="middle" style="border-width: 1px 1px 0 0; border-color:#ccc; border-style: solid;padding: 8px;">{{ $comment }}</td>
            </tr>
                                           
                                        </tbody>
                                    </table></td></tr>
        
      <tr>
        <td bgcolor="#fe9126" style="height: 25px; color: #FFF; text-align: center;" >© 2017 Shop Day. All rights reserved</td>
      </tr>
      <tr>
        <td  height="20"></td>
      </tr>
      <tr>
        <td style="text-align:center;"></td>
      </tr>
    </table>
      
  </div>
</div>
</body>
</html>
