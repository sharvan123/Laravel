<!DOCTYPE html>
<html>
<head>
<title>@yield('title') </title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shop Day" />

<!-- header -->
@include('Common.header')
	<!-- navigation -->
@include('Common.menu')		
<!-- //navigation -->

@yield('content')

@include('Common.footer')

@yield('script')
</body>
</html>		