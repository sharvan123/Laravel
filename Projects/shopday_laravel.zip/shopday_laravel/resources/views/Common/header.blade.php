<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
{!! Html::style('css/bootstrap.css') !!}
{!! Html::style('css/style.css') !!}
<!-- font-awesome icons -->
{!! Html::style('css/font-awesome.css') !!}
<!-- //font-awesome icons -->
<!-- js -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- //js -->
<link href='//fonts.googleapis.com/css?family=Raleway:400,100,100italic,200,200italic,300,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- start-smoth-scrolling -->
{!! Html::script('js/move-top.js') !!}
{!! Html::script('js/easing.js') !!}
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
</head>
	
<body>
<!-- header -->
	<div class="agileits_header">
		<div class="container">
			<div class="w3l_offers">
				<p>SALE UP TO 70% OFF. USE CODE "SALE70%" . <a href="products.html">SHOP NOW</a></p>
			</div>
			<div class="agile-login pull-right">
				<ul>
					@if(Auth::user())
					<li><a href="javascript:void(0);" style="color: #fe9126;" >{{ Auth::user()->name }}</a></li>
					<li><a href="{{ URL::to('logout') }}">Logout</a></li>
					<li><a href="{{ URL::to('my_account') }}">My Account </a></li>
					@else
					<li><a href="{{ URL::to('register') }}"> Create Account </a></li>
					<li><a href="{{ URL::to('login') }}">Login</a></li>
					@endif
					<li><a href="javascript:void(0);"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i> Cart </a></li>
					<!-- <li><a href="contact.html">Help</a></li> -->
					
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>

	<div class="logo_products">
		<div class="container">
		<div class="w3ls_logo_products_left1">
				<ul class="phone_email">
					<li><i class="fa fa-phone" aria-hidden="true"></i>Order online or call us : (+0123) 234 567</li>
					
				</ul>
			</div>
			<div class="w3ls_logo_products_left">
				<h1><a href="{{ URL::to('/') }}">Shop Day</a></h1>
			</div>
		<div class="w3l_search">
			<form action="#" method="post">
				<input type="search" name="Search" placeholder="Search for a Product..." required="">
				<button type="submit" class="btn btn-default search" aria-label="Left Align">
					<i class="fa fa-search" aria-hidden="true"> </i>
				</button>
				<div class="clearfix"></div>
			</form>
		</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
