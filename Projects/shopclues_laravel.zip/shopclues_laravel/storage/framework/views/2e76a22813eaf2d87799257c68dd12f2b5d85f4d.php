<!-- Top nav-->
<?php echo $__env->make('blogs.admin.inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Top nav end-->
<!-- main content-->
<div id="layoutSidenav">
<!-- side nav-->
<?php echo $__env->make('blogs.admin.inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- side nav end-->
<!-- content-->
<div id="layoutSidenav_content">
<!-- content-->          
                <main>
                   <div class="container-fluid">
                   <br><br>

                   <div class="row">
                       <h3>Read Category</h3>
                       <hr>
                        <div class="card" style="width:100%">
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Read Blogs Category
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <address style="letter-spacing: 2px; background-color: aquamarine; padding:25px">   
                                     <b>Id : <?php echo e($data->id); ?> </b><br>
                                  
                                     <b>Category : <?php echo e($data->catname); ?> </b><br>
                                  
                                     <b>Registered Date : <?php echo e($data->addeddate); ?> </b><br>
                                  <br>
                                  
                                     <a href='<?php echo e(url("destroy/{$data->id}")); ?>' class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to Delete Data')"><span class="fa fa-trash"></span> Delete</a>
                                  
                                  </address>
                                  
                                  
                                    </table>
                                </div>
                            </div>
                        </div>








                   
                </main>

                </div>
                
                </div>
                
                </div>
                
                </div>
                <!-- content-->
                <!-- footer-->
                <?php echo $__env->make('blogs.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer-->
                </div>
            <!-- content end-->
        </div>
        <!-- main content end-->
<?php echo $__env->make('blogs.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/admin/readcategory.blade.php ENDPATH**/ ?>