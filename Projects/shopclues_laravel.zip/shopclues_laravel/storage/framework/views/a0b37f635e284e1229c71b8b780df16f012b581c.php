<!-- Top nav-->
<?php echo $__env->make('blogs.admin.inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Top nav end-->
<!-- main content-->
<div id="layoutSidenav">
<!-- side nav-->
<?php echo $__env->make('blogs.admin.inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- side nav end-->
<!-- content-->
<div id="layoutSidenav_content">
<!-- content-->
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Add Blogs Category</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Blogs Category</li>
                        </ol>


                        <div class="row">
                        
                    <div class="col-xl-6 col-md-6">

                    <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo Session::get('success'); ?></strong>
            </div>
        <?php endif; ?>

                         <div class="jumbotron">   

                           <form method="post" action="<?php echo e(url('/update',array($data->id))); ?>">

                           <?php echo csrf_field(); ?>
                           
                        <div class="form-group">
                         <label>Enter Blog Category</label>
                         <input type="text" name="catname" placeholder="Enter Category" class="form-control <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($data->catname); ?>" autocomplete="catname" autofocus>

                         <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>   



           
                        <div class="form-group">
                         <label>Select Add Date</label>
                         <input type="date" name="adddate" placeholder="Enter Addded date" class="form-control <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($data->addeddate); ?>" autocomplete="catname" autofocus>

                       <?php if ($errors->has('adddate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adddate'); ?>
                     <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        </div>   


                        <div class="form-group">
                         <input type="submit" name="updcategory" value="UpdateCategory" class="btn btn-lg btn-success">
                           
                        </div>   


                        </div>   


                           </form>
                        
                    </div>
                          
                    </div>
                          
                    </div>
                </main>
                <!-- content-->
                <!-- footer-->
                <?php echo $__env->make('blogs.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer-->
                </div>
            <!-- content end-->
        </div>
        <!-- main content end-->
<?php echo $__env->make('blogs.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/admin/editcategory.blade.php ENDPATH**/ ?>