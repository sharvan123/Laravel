<!DOCTYPE html>
<html>
<head>
  <script src="https://cdn.tiny.cloud/1/4bep39q1z5ss46n0jsfg72oan2ix2e06jt0m9dedevkr3cks/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
</head>
<body>


<!-- Top nav-->
<?php echo $__env->make('blogs.admin.inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Top nav end-->
<!-- main content-->
<div id="layoutSidenav">
<!-- side nav-->
<?php echo $__env->make('blogs.admin.inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div id="layoutSidenav_content">
<!-- content-->
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Add Blogs Here</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Add Blogs </li>
                        </ol>


                        <div class="row">
                        
                            <div class="col-xl-6 col-md-6">
             <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo Session::get('success'); ?></strong>
            </div>
        <?php endif; ?>
                         
                         <div class="jumbotron">   

                           <form method="post" action="<?php echo e(url('admin/AddBlogs')); ?>" enctype="multipart/form-data">
                           <?php echo csrf_field(); ?>

                        
                        <div class="form-group">
                         <label>Select Blogs Category</label>
                         <select  name="catname" placeholder="Enter Category" class="form-control <?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  autocomplete="catname" autofocus>


                        <option value="">-select Category-</option>
                       
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                       <option value="<?php echo e($key); ?>"><?php echo e($cat); ?></option>



                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      

                        </select>



                       
                       
<?php if ($errors->has('catname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('catname'); ?>
<span class="invalid-feedback" role="alert">
      <strong><?php echo e($message); ?></strong>
</span>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>   
   
                           
                        <div class="form-group">
                         <label>Enter Blog Title</label>
                         <input type="text" name="title" placeholder="Enter Blogs Title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="" autocomplete="title" autofocus>


                        
                         <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        </div>   


                        <div class="form-group">
                         <label>Upload Blogs Image</label>
                         <input type="file" name="img" class="form-control <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="" autocomplete="img" autofocus>

                         <?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>   



                        <div class="form-group">
                         <label>Add Blogs Date</label>
                         <input type="date" name="bdate" placeholder="Enter Blogs Date" class="form-control <?php if ($errors->has('bdate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bdate'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="" autocomplete="bdate" autofocus>

                         <?php if ($errors->has('bdate')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bdate'); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>




                        
                        <div class="form-group">
                         <label>Descriptions of Blogs</label>
                        
                         <textarea id="mytextarea" name="desc" class="form-control <?php if ($errors->has('desc')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desc'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="" autocomplete="desc" autofocus></textarea>

                         <?php if ($errors->has('desc')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('desc'); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                        </div>      



                        <div class="form-group">
                         <input type="submit" name="addblogs" value="AddBlogs" class="btn btn-lg btn-success">
                           
                        </div>   


                        </div>   


                           </form>


                              






                        
                    </div>
                          
                    </div>
                          
                    </div>
                </main>
                <!-- content-->
                <!-- footer-->
                <?php echo $__env->make('blogs.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer-->
                </div>
            <!-- content end-->
        </div>
        <!-- main content end-->



          <script>
    tinymce.init({
      selector: 'textarea',
      plugins: '',
      toolbar: '',
      toolbar_mode: 'floating',
      });
  </script>


</html>
</body>
    
<?php echo $__env->make('blogs.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/admin/addblogs.blade.php ENDPATH**/ ?>