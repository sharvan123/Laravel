<!-- Top nav-->
<?php echo $__env->make('blogs.admin.inc.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Top nav end-->
<!-- main content-->
<div id="layoutSidenav">
<!-- side nav-->
<?php echo $__env->make('blogs.admin.inc.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- side nav end-->
<!-- content-->
<div id="layoutSidenav_content">
<!-- content-->          
                <main>
                   <div class="container-fluid">
                   <br><br>

                   <div class="row">

                  


                       <h3>Manage All Category</h3>
                       <hr>
                        <div class="card" style="width:100%">
                           
                           
                   <?php if(Session::has('delsuccess')): ?>
            <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo Session::get('delsuccess'); ?></strong>
            </div>
        <?php endif; ?>





        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <strong><?php echo Session::get('success'); ?></strong>
            </div>
        <?php endif; ?>
                            <div class="card-header">
                                <i class="fas fa-table mr-1"></i>
                                Show all Blogs Category
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Id</th>
                                                <th>Category Name</th>
                                                <th>Registered Date</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </thead>
                                  
                     
                                        <tbody>

                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($row->id); ?></td>
                                                <td><?php echo e($row->catname); ?></td>
                                                <td><?php echo e($row->addeddate); ?></td>
                                                <td>

                                                <a href='<?php echo e(url("readcategory/{$row->id}")); ?>' class="btn btn-sm btn-info"><span class="fa fa-read"></span> Read</a> |
                                               <a href="" class="btn btn-sm btn-success"><span class="fa fa-watsapp"></span> Sendwatsap</a> |
                                                
                                               <a href='<?php echo e(url("destroy/{$row->id}")); ?>' class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to Delete Data')"><span class="fa fa-trash"></span> Delete</a>
                                                |
                                                <a href='<?php echo e(url("editcategory/{$row->id}")); ?>' class="btn btn-sm btn-info"><span class="fa fa-edit"></span> Edit</a>
                                                </td>
                                               
                                            </tr>

                                            
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                            </tbody>


                                    </table>
                                </div>
                            </div>
                        </div>








                   
                </main>



                </div>
                
                </div>
                
                </div>
                
                </div>
                <!-- content-->
                <!-- footer-->
                <?php echo $__env->make('blogs.admin.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- footer-->
                </div>
            <!-- content end-->
        </div>
        <!-- main content end-->
<?php echo $__env->make('blogs.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopclues\resources\views/blogs/admin/showblogscategory.blade.php ENDPATH**/ ?>